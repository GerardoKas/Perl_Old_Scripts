$dir=shift @ARGV;

if ($dir eq "" ) {
	die "Falta el directorio";
}
opendir(DR,$dir);
@files=readdir(DR);
closedir(DR);
chdir($dir);
#############
#
##
#   CAMBIAR AQUI EL NUMERO DE DIGITOS DEL FILENAME

 $numdigits=3;

#
##
#
#############

foreach(@files){
  next if ($_=~/^\./);
  #print "## $_ ##\n";
  $_=~/(\d+)/;
  $n=$1;#digitos reales
  $dif=$numdigits-length($n);#digitos que faltan
  $new="0"x$dif.$n;
  $newname=$_;
  $newname=~s/$n/$new/;
  print "$_ --> $newname\n";
  rename($_,$newname);
  #system("pause");
}

print "DONE!";

