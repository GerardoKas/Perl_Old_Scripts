$dir=shift @ARGV;

$dir=~s/\\$//;;
$data_search="$dir\\data_search.txt";
$data_replace="$dir\\data_replace.txt";
print "\n";
if (!-d $dir){
die("Se necesita Un Directorio de Archivos [[$dir]]");
}
if (!-e $data_search){
print "No existe (FICHERO_SEARCH)'$data_replace' ..";
die("Se necesita Dicho Fichero Para BuscarTexto");
}
if(!-e $data_replace){
print "No existe (FICHERO_REPLACE)'$data_replace' ..";
die("Se necesita Dicho Fichero Para ReemplazarTexto")
}

$original=read_all($data_search);
$reemplazo=read_all($data_replace);
$original=takeBadChars($original);
#COPIAR FICHERO DE BUSQUEDA COMO .DATA
 
$operacion=2;#1=buscar..2=reemplazar
$total=0;
$nfiles=0;

use File::Find 'find';
find(\&DoIt,$dir);
print "\n\n $total FICHEROS CON EL DATO DE $nfiles TOTALES\n\n";
sub DoIt{
  $file=$_;
  next if $file=~/^\./;
  next if $file!~/\.(html?|txt|php)$/;
  next if $file=~/(data_search|data_replace)/;
  $texto=read_all($file);
  $tiene=0;
  $fn=$file;
  print "$fn - ";
  if ($operacion==1){
    $tiene=$texto=~/$original/gmi;
    print "($tiene Found)"
  }else{
    $tiene=$texto=~s/$original/$reemplazo/gmi;
    open(FILE,">$file");
    print FILE $texto;
    close FILE;
    print "($tiene Replaced)";
  }
  
    if($tiene>0){$total++};
    $nfiles++;
    print "\n";
}

sub read_all{
my ($file)=@_;
open(FILE,"<$file") or die "No se puede abrir $file";
@lines=<FILE>;
close FILE;
$data=join("",@lines);
return $data;
}

sub takeBadChars{
  my($cad)=@_;
#   $cad=~s/\?/\?/g;
#   $cad=~s|\/|\/|g;
#   $cad=~s|\\|\\|g;
#   $cad=~s|\!|\!|g;
  #$cad=~s[(\.|\/|\\)][\\1]g;
  $cad=quotemeta ($cad);
  return $cad;
}
