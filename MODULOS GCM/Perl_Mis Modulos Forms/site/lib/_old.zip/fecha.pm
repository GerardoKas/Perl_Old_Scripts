package fecha;

######################################################v
sub fecha::fecha{
($sec,$min,$hour,$mday,$mon,$year)=it(time);
return "<font size=-1>Pagina creada en $mday/$mon/$year, a las $hour:$min:$sec</font><br>\n";
}
##########################################
sub fecha::segundos{
return time;
}
##########################################
sub fecha::secstotime{
my ($secs)=@_;
$mins=int($secs/60);
$rsecs=$secs-$mins*60;
$horas=int($mins/60);
$rmins=$mins-$horas*60;
return ($horas,$rmins,$rsecs)
}
#######################################v
sub fecha::it{
my($segundos)=@_;
($sec,$min,$hour,$mday,$mon,$year)=localtime($segundos);
#$mday+=1;
$mon+=1;
if ($year>99){
	$year=$year-99;
	$year=1999+$year;
	}
return ($sec,$min,$hour,$mday,$mon,$year);
}
##########################################v
sub fecha::tostring{
	my($tiempo,$cual)=@_;
#$cual puede ser "hora" "fecha" "horafecha"
($sec,$min,$hour,$mday,$mon,$year)=localtime($tiempo);
$mon+=1;
if ($year>99){
	$year=$year-99;
	$year=1999+$year;
	}
	if ($cual eq "hora"){
		return "$hour:$min:$sec";
	}elsif ($cual eq "fecha"){
		return "$mday/$mon/$year"
	}else{
		return "$mday/$mon/$year,$hour:$min:$sec";
	}

}
################################################
1