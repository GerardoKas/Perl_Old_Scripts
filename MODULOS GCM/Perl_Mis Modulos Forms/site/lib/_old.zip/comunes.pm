package comunes;


sub comunes::getFile{
    my($file)=@_;
    my(@txt,$fmt);
    open(DATA,"<$file") or die "getFile::NO SE PUEDE ABRIR $file\n";
    @txt=<DATA>;
    close DATA;
    $fmt=join("",@txt);
    return $fmt;
}

sub evalFile{
    my($archivo)=@_;
    my(@LINES,$tut);
    
    unless(open(COD,"<$archivo")){
        print "evalFile::NO SE ENCUENTRA $archivo";
    exit;
    }
    @LINES=<COD>;
    close COD;
    $tut=join("",@LINES);
 
    $tut="print <<HTML;\n <!--CODE=$archivo-->\n".$tut."\n<!--ENDCODE-->\nHTML\n";
    eval($tut);
   
}     