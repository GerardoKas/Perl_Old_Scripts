use forms();
use cadenas();
$cgibin="/cgi-bin/GO/";
@tits=('todo','hyper','view');
@prgs=('ALL FILES.pl','HIPERTEXTOS.pl','IMAGeNES.pl');
@desc=('Ver Archivos (todos)','Ver Hipertextos','Ver imagenes');
#%HASH=('todo','all files.pl', 'hyper','hipertextos.pl','view','imagenes.pl');
#print forms::getvalue("dir");
if($value=forms::getvalue('x')){
	$dir=forms::getvalue('dir');
	print $dir;
	for ($i=0;$i<=$#tits;$i++){
			if ($tits[$i] eq $value){
			$program=$prgs[$i];
			last;
			}
	#$program=$prz[];
	}
print "//<script>alert('$value::----$dir----');\nwindow.location='$cgibin$program?dir=$dir'</script>";

}else{
#imprimir el formulario de busqueda
$body=cadenas::bodyoscuro();
print <<FIN;
<title>Introducir Datos de Busqueda</title>
<style>
input{font-family:terminal;font-weight:thin;font-size:8;}
</style>
<script>
window.resizeTo(300,400);
//alert ((screen.width/2)-300+", "+(screen.height/2))
window.moveTo((screen.width-300)/2,(screen.height-500)/2)
function go(){
var ef=document.forma.file
var we=String.fromCharCode(92)
//var wo=String.fromCharcode(47) //esta da error????
		pos=ef.value.lastIndexOf("/",ef.value.length)
	   if (pos==-1) {
			 pos=ef.value.lastIndexOf(we,ef.value.length)
          if(pos!=-1){
			 	document.forma.dir.value=ef.value.substring(0,pos)
      	}else{
			document.forma.dir.value=ef.value
			}
		}else{
	   	document.forma.dir.value=ef.value.substring(0,pos)
		}
		//alert ("DIRECTORIO::"+document.forma.dir.value)
		window.moveTo(0,0);
		window.resizeTo(screen.width,screen.height);
	   return true

}
</script>
$body
<center>
<form name=forma onsubmit="if(!go())return false">
<br>
<hr width=150>
FIN
for ($i=0;$i<=$#tits;$i++){
	print "<input type=radio name=x value=$tits[$i]>$desc[$i]<BR>\n";
	}

print <<FIN;

<hr width=70>
DIRECTORIO:<br><input type=file name=file><br>
<input type=hidden name=dir><br><hr width=50>
<input type=submit value="BUSCAR"><hr width=50>
</center>
FIN
}