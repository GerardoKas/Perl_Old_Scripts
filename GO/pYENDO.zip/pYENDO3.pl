use forms();
use cadenas();
$cgibin="/cgi-bin/GO/";
@tits=('todo','hyper','view');
@prgs=('ALL FILES.pl','HIPERTEXTOS.pl','IMAGeNES.pl');
@desc=('Ver todos los Archivos','Ver Hipertextos','Ver imagenes');
#%HASH=('todo','all files.pl', 'hyper','hipertextos.pl','view','imagenes.pl');

#print "ESTO IMPRIME LA CADENA ENVIADA POR GET:<br>\n";
if(%data=forms::form){
	$dir=$data{'dir'};
	for ($i=0;$i<=$#tits;$i++){
			if ($tits[$i] eq $data{'x'}){
			$program=$prgs[$i];
			last;
			}
	#$program=$prz[];
	}
print "<script>alert('$data{'dir'}');window.location='$cgibin$program?dir=$dir'</script>";

}else{
#imprimir el formulario de busqueda
$body=cadenas::bodyoscuro();
print <<FIN;
<title>Introducir Datos de Busqueda</title>
<script>
function go(){
var ef=document.forma.file
var we=String.fromCharCode(92)
//var wo=String.fromCharcode(47) //esta da error????
	if (ef.value=="") {
		alert("DEbes elegir un archivo");
	   return false
	}else{
		pos=ef.value.lastIndexOf("/",ef.value.length)
	   if (pos==-1) {
			 pos=ef.value.lastIndexOf(we,ef.value.length)
          if(pos!=-1){
			 	document.forma.dir.value=ef.value.substring(0,pos)
				//rex=new RegExp(we);
				rex=/\\\\/;
				document.forma.dir.value.replace(rex,"\\\\\\\\");
      	}else{
			document.forma.dir.value=ef.value
			}
		}else{
	   	document.forma.dir.value=ef.value.substring(0,pos)
		}
		alert ("DIRECTORIO::"+document.forma.dir.value)
	   return true
	}
}
</script>
$body
<form name=forma onsubmit="if(!go())return false">
<br>
FIN
for ($i=0;$i<=$#tits;$i++){
	print "<input type=radio name=x value=$tits[$i]>$desc[$i]<BR>\n";
	}

print <<FIN;
<br>
DIRECTORIO:<input type=file name=file><br>
<input type=hidden name=dir>
<input type=submit value="BUSCAR">
FIN
}