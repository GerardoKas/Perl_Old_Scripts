use forms();
use cadenas();
$cgibin="/cgi-bin/";
$values=('todo', 'all files','hyper','hipertextos.pl','view','imagenes.pl');
#print "ESTO IMPRIME LA CADENA ENVIADA POR GET:<br>\n";
if(%data=forms::form){
	foreach $key(keys(%data)){
	print "$key -> $data{$key}<br>";
	}

	$dir=$data{'dir'};
	$program=$values{$x};
print "<script>alert(2);window.location='$cgibin$program?$dir'</script>";

}else{
#imprimir el formulario de busqueda
$body=cadenas::bodyoscuro();
print <<FIN;
<title>Introducir Datos de Busqueda</title>
<script>
function go(){
var ef=document.forma.file
var we=String.fromCharCode(92)
//var wo=String.fromCharcode(47) //esta da error????
	if (ef.value=="") {
		alert("DEbes elegir un archivo");
	   return false
	}else{
		pos=ef.value.lastIndexOf("/",ef.value.length)
	   if (pos==-1) pos=ef.value.lastIndexOf(we,ef.value.length)
	   alert(pos)
	   document.forma.dir.value=ef.value.substring(0,pos)
	   return true
	}
}
</script>
$body
<form name=forma onsubmit="if(!go())return false">
<input type=radio name=x value=todo>BUSCAR TODOS LOS ARCHIVOS<BR>
<input type=radio name=x value=hyper>Buscar archivos de Hipertexto<BR>
<input type=radio name=x value=view>Ver imagenes<BR>
<input type=radio name=x value=find>Buscar una cadena de texto<BR>
<input type=radio name=x value=links>Links de las Paginas de Hipertexto<BR>
<input type=radio name=x value=titles>Titulos de las paginas<BR>
<br>
DIRECTORIO:<input type=file name=file><br>
<input type=hidden name=dir>
<input type=submit value="BUSCAR">
FIN
}