$DEB=1;
print "NO USAR ESTO; PUEDE BORRAR TU CONFIANZA\n";
<>;

$file="Rpeyecto de Ofstware.txt.htm";




open(FIL,"<$file") or die("error tonto");
@lines=<FIL>;
close FIL;
################################
$stilo='<style[^>]*>';
$cstilo='<\/style[^>]*>';
$etiq='<(\w+)[^>]*>';
$cetiq='<\/(\w+)[^>]*>';
################################

###############
$ret="\n";
$nret=0;
$ntex=0;
###############
for (@lines){
if(/^[\s\n]$/){
$nret++;
}
if(/^[^\s\n]+$/i){
$ntex++;


}
}
print "$ntex FRASES SOLAS\n";
print "$nret ENTERES SOLOS\n";


exit;


$mkstilo=0;
$num=0;
$numeti=0;
for (@lines){
#print    $_;
   if(/$stilo/i){
   #SI TIENE ETIQUETA DE ESTILO
print "ESTILO INICIA" if $DEB;
   $mkstilo=1;
   next;
   }
   if(/$cstilo/i){
      $mkstilo=0;
print "ESTILO FIN\n" if $DEB;
   }elsif ($mkstilo==1){
#print "NEX\n" if $DEB;
      next;
   }
      if(/^($etiq|$cetiq)+$/i){
      #TIENE ETIQ AL PRINCIPIO Y AL FINAL

#print $_ if $DEB;
$numeti++;
      }else{
#print "NOETI";
$num++;
      #ES LINEA DE TEXTO PARA MODIFICAR;
      if (length($_)>120){
         $br="<br><br>";
      }else{
         $br="<br>";
      }
      chop($_);
      $_.=$br;
      }
}
print "\n$num LINEAS SOLO TEXTO ENCONTRADAS\n";
print "$numeti LINEAS SOLO ETIQUETA ENCONTRADAS\n" if $DEB;
print "$#lines LINEAS TOTALES\n" if $DEB;

open (WRI,">0$file.HTM") or die ("CAnnot Escribir ops");
print WRI @lines;
close WRI;
