$DEB=1;
print @_;

$file="Rpeyecto de Ofstware.txt.htm";




open(FIL,"<$file") or die("error tonto");
@lines=<FIL>;
close FIL;
$e="&nbsp;";
$tab="&nbsp;&nbsp;&nbsp;&nbsp;";
$stilo="<style[^>]*>";
$cstilo='<\/style[^>]*>';
$etiq='<(\w+)[^>]*>';
$cetiq='<\/(\w+)[^>]*>';
$mkstilo=0;
$num=0;
$numeti=0;
for (@lines){
#print    $_;
   if(/$stilo/i){
   #SI TIENE ETIQUETA DE ESTILO
print "ESTILO INICIA" if $DEB;
   $mkstilo=1;
   next;
   }
   if(/$cstilo/i){
      $mkstilo=0;
print "ESTILO FIN\n" if $DEB;
   }elsif ($mkstilo==1){
#print "NEX\n" if $DEB;
      next;
   }
   
   
   if(/^($etiq|$cetiq)+$/i){
   #TIENE ETIQ AL PRINCIPIO Y AL FINAL
      #print $_ if $DEB;
      $numeti++;
   }else{
   #ES TEXTO NOTRMAL
      $num++;
      s/^( ){2,}/&nbsp;/g;
      if (length($_)>120){
         $br="\n<br><br>";
      }elsif(length($_)>240){
         $br="\n<br><br><br>";
      }else{
         $br="\n<bR>";
      }
      chop($_);
      $_.=$br;
      }
      s/\t/$tab/g;
      
      
}
print "\n$num LINEAS SOLO TEXTO ENCONTRADAS\n";
print "$numeti LINEAS SOLO ETIQUETA ENCONTRADAS\n" if $DEB;
print "$#lines LINEAS TOTALES\n" if $DEB;
open (WRI,">0$file.HTM") or die ("CAnnot Escribir ops");
print WRI @lines;
close WRI;
